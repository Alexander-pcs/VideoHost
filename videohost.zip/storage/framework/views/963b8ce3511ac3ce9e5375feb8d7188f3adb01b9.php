<?php $__env->startSection('content'); ?>
<div class="main">
    <div class="content_left">
        <div class="ui">
            <img src="images/menu/logo_video_host.png" width="60" height="35">
            <div class="icons_menu">
                <a href="">
                    <div class="burger_menu"></div>
                </a>
                <a href="">
                    <div class="home"></div>
                </a>
                <a href="file:///D:/VideoHost/index.html">
                    <div class="trend"></div>
                </a>
            </div>
        </div>
        <div class="slide_menu">
            <img src="images/lk/content_left.png">
            <div class="info">
                <h1>PewDiePie</h1>
                <h1 id="hh">Статистика:</h1>
                <ul>
                    <li>Добавлено видео(500+)</li>
                    <li>Подписчики(109млн)</li>
                    <li>Просмотры(27млн)</li>
                    <li>Дата регистрации(29.04.2010)</li>
                </ul>
            </div>
        </div>
    </div>
    <div class="content_right">
        <div class="box_search">
            <form>
                <input type="text" placeholder="Введите запрос">
                <button type="submit"></button>
            </form>
        </div>
        <div class="categoryies">
            <a href="#">
                <div class="news"></div>
            </a>
            <a href="/game">
                <div class="games"></div>
            </a>
            <a href="#">
                <div class="music"></div>
            </a>
            <a href="#">
                <div class="podcast"></div>
            </a>
            <a href="#">
                <div class="sport"></div>
            </a>
        </div>
        <div class="trending_video">
            <div class="text_logo">
                <img src="images/logo/logo_trend.svg">
                <h1>В тренде</h1>
            </div>
            <div class="content_box_1">
                <div class="scale">
                    <a href="#">
                        <div class="box_trend">
                            <img src="images/trend/preview_1.jpg">
                            <h3>ВандаВижн - разбор 8 серии. Ответы
                                на главные вопросы!</h3>
                            <h2>Marvel/DC: Geek Movies<br>
                                250 тыс. просмотров</h2>
                        </div>
                    </a>
                </div>
                <div class="scale">
                    <a href="/watching">
                        <div class="box_trend">
                            <img src="images/trend/preview_2.jpg">
                            <h3>Гавайи. Оаху во всей красе. Большой
                                выпуск.</h3>
                            <h2>Антон Птушкин<br>
                                4,9 млн просмотров</h2>
                        </div>
                    </a>
                </div>
                <div class="scale">
                    <a href="#">
                        <div class="box_trend">
                            <img src="images/trend/preview_3.jpg">
                            <h3>Небольшая проблема</h3>
                            <h2>slidan<br>
                                650 тыс. просмотров</h2>
                        </div>
                    </a>
                </div>
            </div>
            <div class="content_box_2">
                <div class="scale">
                    <a href="#">
                        <div class="box_trend">
                            <img src="images/trend/preview_4.jpg">
                            <h3>24 ЧАСА В ПЕЩЕРЕ ЧТОБЫ ВЫЖИТЬ! ФИНАЛ ПРОЕКТА</h3>
                            <h2>Дима Масленников<br>
                                2,4 млн просмотров</h2>
                        </div>
                    </a>
                </div>
                <div class="scale">
                    <a href="#">
                        <div class="box_trend">
                            <img src="images/trend/preview_5.jpg">
                            <h3>SEEMEE & SODA LUV - Голодный пёс |
                                Toaster Live</h3>
                            <h2>TOASTER<br>
                                1,5 млн просмотров</h2>
                        </div>
                    </a>
                </div>
                <div class="scale">
                    <a href="#">
                        <div class="box_trend">
                            <img src="images/trend/preview_6.jpg">
                            <h3>КАК ВЫРАСТИТЬ МАНГО ИЗ
                                СЕМЕЧКИ</h3>
                            <h2>SlivkiShow<br>
                                1,6 млн просмотров</h2>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\nginx-1.19.2\html\19279\carrow\resources\views/index.blade.php ENDPATH**/ ?>