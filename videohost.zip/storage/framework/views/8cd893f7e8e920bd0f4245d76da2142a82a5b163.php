<?php $__env->startSection('content4'); ?>
<div class="main">
    <div class="ui">
        <img src="images/menu/logo_video_host.png" width="60" height="35">
        <div class="icons">
            <a href="">
                <div class="burger_menu"></div>
            </a>
            <a href="/index">
                <div class="home"></div>
            </a>
            <a href="/index">
                <div class="trend"></div>
            </a>
        </div>
    </div>
    <div class="content">
        <div class="video">
            <iframe width="1280" height="720" src="https://www.youtube.com/embed/kwPqZyS2ttA"
                    frameborder="0" allow="accelerometer; autoplay; clipboard-write;
              encrypted-media; gyroscope; picture-in-picture" allowfullscreen>
            </iframe>
        </div>
        <div class="first_string">
            <div class=left_cnt>
                <h1>Гавайи. Оаху во всей красе. Большой выпуск.</h1>
                <h3>7 791 330 просмотров 23 февр. 2021 г.</h3>
            </div>
            <div class=right_cnt>
                b
                <div id="mrgn" class=like>
                    <img src="images/watch/like.svg">
                    <h4>369 тыс.</h4>
                </div>
                <div id="mrgn" class=share>
                    <img src="images/watch/share.svg">
                    <h4>Поделиться</h4>
                </div>
                <div class=favorite>
                    <img src="images/watch/favorite.svg">
                    <h4>Добавить в избранное</h4>
                </div>
            </div>
        </div>
        <hr align="left" width="1276" size="1" color=" #000 ">
        <div class="second_string">
            <div class="l_cnt">
                <img src="images/watch/avatar.png">
                <ul>
                    <li id="name">Андрей Птушкин</li>
                    <li id="subscribers">4,55 млн подписчиков</li>
                </ul>
            </div>
            <div class="r_cnt">
                <button class="sub_btn">Подписаться</button>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.headerwatching', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH Z:\carrow\resources\views/watching.blade.php ENDPATH**/ ?>