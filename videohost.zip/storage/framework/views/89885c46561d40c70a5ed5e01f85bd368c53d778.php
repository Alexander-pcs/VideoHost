<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>VideoHost</title>
    <link rel="stylesheet" href="css/style_1.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=PT+Sans:wght@400;700&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=PT+Sans:wght@400;700&family=Roboto:wght@700&display=swap"
          rel="stylesheet">
</head>
<body>
<?php echo $__env->yieldContent('content'); ?>
</body>
</html>
<?php /**PATH C:\nginx-1.19.2\html\19279\carrow\resources\views/layouts/header.blade.php ENDPATH**/ ?>