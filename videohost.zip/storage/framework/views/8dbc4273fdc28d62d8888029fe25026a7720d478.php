<?php $__env->startSection('content3'); ?>
<div class="main">
    <div class="container">
        <div class="reg_window">
            <div class="content">
                <h1>Регистрация</h1>
                <form action="/register" method="post">
                    <?php echo e(csrf_field()); ?>

                    <h3>Введите имя</h3>
                    <p>
                        <input type="text" name="name" placeholder="Александр" required>
                    </p>
                    <h3>Введите почту</h3>
                    <p>
                        <input type="email" name="email" placeholder="example@mail.ru" required>
                    </p>
                    <h3>Придумайте пароль</h3>
                    <p>
                        <input type="password" name="password" placeholder="qwerty123">
                    </p>
                    <button type="submit">Зарегистрироваться</button>
                </form>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.headerregister', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\carrow\resources\views/register.blade.php ENDPATH**/ ?>