@extends('layouts.headergame')


@section('content2')
<main>
    <div class="menu">
        <img src="images/menu/logo_video_host.png" width="60" height="35">
        <div class="icons_menu">
            <a href="">
                <div class="burger_menu"></div>
            </a>
            <a href="/">
                <div class="home"></div>
            </a>
            <a href="#">
                <div class="trend"></div>
            </a>
        </div>
    </div>
    <div class="container">
        <h1>Games</h1>
        <div class="video_container">
            <a href="#">
                <div class="video_container">
                    <div class="video">
                        <img src="" alt="">
                        <div class="name">
                            <h2>Lorem ipsum</h2>
                            <ul>
                                <li>Lorem ipsum</li>
                                <li>Lorem ipsum</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </a>
            <a href="#">
                <div class="video_container">
                    <div class="video">
                        <img src="" alt="">
                        <div class="name">
                            <h2>Lorem ipsum</h2>
                            <ul>
                                <li>Lorem ipsum</li>
                                <li>Lorem ipsum</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </a>
            <a href="#">
                <div class="video_container">
                    <div class="video">
                        <img src="" alt="">
                        <div class="name">
                            <h2>Lorem ipsum</h2>
                            <ul>
                                <li>Lorem ipsum</li>
                                <li>Lorem ipsum</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </a>
            <a href="#">
                <div class="video_container">
                    <div class="video">
                        <img src="" alt="">
                        <div class="name">
                            <h2>Lorem ipsum</h2>
                            <ul>
                                <li>Lorem ipsum</li>
                                <li>Lorem ipsum</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </a>
            <a href="#">
                <div class="video_container">
                    <div class="video">
                        <img src="" alt="">
                        <div class="name">
                            <h2>Lorem ipsum</h2>
                            <ul>
                                <li>Lorem ipsum</li>
                                <li>Lorem ipsum</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </a>
            <a href="#">
                <div class="video_container">
                    <div class="video">
                        <img src="" alt="">
                        <div class="name">
                            <h2>Lorem ipsum</h2>
                            <ul>
                                <li>Lorem ipsum</li>
                                <li>Lorem ipsum</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </a>
        </div>
    </div>
</main>
@endsection
