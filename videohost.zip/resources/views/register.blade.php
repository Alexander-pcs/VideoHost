@extends('layouts.headerregister')


@section('content3')
<div class="main">
    <div class="container">
        <div class="reg_window">
            <div class="content">
                <h1>Регистрация</h1>
                <form action="/register" method="post">
                    {{csrf_field()}}
                    <h3>Введите имя</h3>
                    <p>
                        <input type="text" name="name" placeholder="Александр" required>
                    </p>
                    <h3>Введите почту</h3>
                    <p>
                        <input type="email" name="email" placeholder="example@mail.ru" required>
                    </p>
                    <h3>Придумайте пароль</h3>
                    <p>
                        <input type="password" name="password" placeholder="qwerty123">
                    </p>
                    <button type="submit">Зарегистрироваться</button>
                </form>

            </div>
        </div>
    </div>
</div>
@endsection
