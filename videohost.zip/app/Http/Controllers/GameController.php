<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Ramsey\Uuid\Exception\UnableToBuildUuidException;

class GameController extends Controller
{
    public function index()
    {
        return view('games');
    }

}
