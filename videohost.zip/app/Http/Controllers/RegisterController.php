<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\models\User;
use Illuminate\Support\Facades\Hash;

class RegisterController extends Controller
{
    public function index()
    {
        return view('register');
    }

    public function create(Request $request) {

        User::create([
            'login'=>$request->name,
            'email_address'=>$request->email,
            'password'=> Hash::make($request->password),
            'status'=>0,
        ]);
        return redirect('/');
    }
}
